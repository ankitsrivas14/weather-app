import styled from "styled-components";

export const Container = styled.div`

`;

export const ChartContainer = styled.div`
  width: 100%;
  height: 200px;
`;

export const StatsContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;

export const Stat = styled.div`
    display: flex;
    flex-direction: column;
`;