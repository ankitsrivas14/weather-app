import styled from "styled-components";

export const ChartContainer = styled.div`
  overflow: scroll;
  margin-bottom: 2rem;
`;